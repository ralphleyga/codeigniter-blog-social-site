<?php
$this->load->view('header');
$this->load->view('home/welcome_home');
$this->load->view('home/right_side');
$this->load->view('footer');
?>