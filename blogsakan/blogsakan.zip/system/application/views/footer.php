
</div><div style="clear: both;">
<br>
<div id="footer">
<p><a href="http://blogksakan.phpnet.us/">BLOGSAKAN! beta</a>, by <a href="http://www.rleyga.tk">RLeyga</a> -  Version <?php echo '1.0.0-beta' ?></p>
<p>E-mail:ralphleyga@yahoo.com or Contact No: +639208747754</p>
<p>Powered by:PHP and MySQL</p>
</div>
</body>
</html>
<!-- END OF SCRIPT -->
<!/SCRIPT>