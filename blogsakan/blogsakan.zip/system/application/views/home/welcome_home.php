<div id="left">
<?php $this->load->view('userpanel');
            ?>
<h2>Welcome to <strong>BLOGSAKAN!</strong></h2>
Welcome to Blogsakan!  Register and be a member of blogsakan to post entries
for free!  This website is not yet completed.  This is only a beta version.
If you are a PINOY, register and share your knowledge.  Post all your experience.

<br>

<?php
$this->load->view('home/top_post'); ?>

</div>