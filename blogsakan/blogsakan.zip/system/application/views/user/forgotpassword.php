<?php
$this->load->view('header');
$this->load->view('home/right_side');
?>
<div id="left">
<h2>Forgot Password?</h2>
<p>E-mail ralphleyga@yahoo.com if you forgot your password.</p>
<p>Send your USERNAME using e-mail.  I will send you the password.  Thank you!</p>
</div>
<?php
$this->load->view('footer');
?>