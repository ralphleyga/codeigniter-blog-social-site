<?php
$this->load->view('header');
$this->load->view('home/right_side');
?>
<div id="left">
<h2>You Have successfully registered. You can now login..</h2>

</div>
<?php
$this->load->view('footer');
?>