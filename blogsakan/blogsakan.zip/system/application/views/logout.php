<?php
$this->load->view('header');
?>
<div id="left">
    <h2>You are not sign in..</h2>
    </div>
<?php
$this->load->view('home/right_side');
$this->load->view('footer');
?>